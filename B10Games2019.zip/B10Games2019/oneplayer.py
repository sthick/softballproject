import pandas as pd
import matplotlib.pyplot as plt

game1 = pd.read_csv("C://Users/saman/Desktop/Independent Study/Softball Project/3-7-19ASU.csv")
game2 = pd.read_csv("C://Users/saman/Desktop/Independent Study/Softball Project/3-13-19Washington.csv")
game3 = pd.read_csv("C://Users/saman/Desktop/Independent Study/Softball Project/3-14-19KentSt.csv")
game4 = pd.read_csv("C://Users/saman/Desktop/Independent Study/Softball Project/3-17-19KentSt2.csv")
game5 = pd.read_csv("C://Users/saman/Desktop/Independent Study/Softball Project/3-17-19KentSt3.csv")
game6 = pd.read_csv("C://Users/saman/Desktop/Independent Study/Softball Project/3-19-19WMichigan.csv")
game7 = pd.read_csv("C://Users/saman/Desktop/Independent Study/Softball Project/3-19-19WMichigan.csv")
game8 = pd.read_csv("C://Users/saman/Desktop/Independent Study/Softball Project/3-23-19Nebraska1.csv")
game9 = pd.read_csv("C://Users/saman/Desktop/Independent Study/Softball Project/3-23-19Nebraska2.csv")
game10 = pd.read_csv("C://Users/saman/Desktop/Independent Study/Softball Project/3-24-19Nebraska3.csv")
game11 = pd.read_csv("C://Users/saman/Desktop/Independent Study/Softball Project/4-3-19Toledo.csv")
game12 = pd.read_csv("C://Users/saman/Desktop/Independent Study/Softball Project/4-5-19Indiana1.csv")
game12["Date"] = "4/5/2019"
game13 = pd.read_csv("C://Users/saman/Desktop/Independent Study/Softball Project/4-6-19Indiana2.csv")
game14 = pd.read_csv("C://Users/saman/Desktop/Independent Study/Softball Project/4-7-19Indiana3.csv")
game14["Date"] = "4/7/2019"
game15 = pd.read_csv("C://Users/saman/Desktop/Independent Study/Softball Project/4-16-19MSU1.csv")
game16 = pd.read_csv("C://Users/saman/Desktop/Independent Study/Softball Project/4-23-19MSU2.csv")
game17 = pd.read_csv("C://Users/saman/Desktop/Independent Study/Softball Project/4-26-19PennState1.csv")
game18 = pd.read_csv("C://Users/saman/Desktop/Independent Study/Softball Project/4-27-19PennState2.csv")
game19 = pd.read_csv("C://Users/saman/Desktop/Independent Study/Softball Project/4-28-19PennState3.csv")
game20 = pd.read_csv("C://Users/saman/Desktop/Independent Study/Softball Project/9-29-18Western.csv")
game21 = pd.read_csv("C://Users/saman/Desktop/Independent Study/Softball Project/9-29-18Central.csv")
game22 = pd.read_csv("C://Users/saman/Desktop/Independent Study/Softball Project/9-30-18UDMercy.csv")
game23 = pd.read_csv("C://Users/saman/Desktop/Independent Study/Softball Project/9-30-18Western.csv")
game24 = pd.read_csv("C://Users/saman/Desktop/Independent Study/Softball Project/10-3-18MSU.csv")
game25 = pd.read_csv("C://Users/saman/Desktop/Independent Study/Softball Project/10-10-18MSU.csv")
game26 = pd.read_csv("C://Users/saman/Desktop/Independent Study/Softball Project/10-18-18UDMercy.csv")

games = [game1, game2, game3, game4, game5, game6, game7, game8, game9, game10, game11, game12, game13, game14, game15, game16, game17, game18, game19, game20, game21, game22, game23, game24, game25, game26]
df = pd.concat(games)
df.fillna(" ",inplace= True)
dates = []
# print(df.columns)

for index, a in df.iterrows():
    if a["Date"] not in dates:
        dates.append(a["Date"])

roster = pd.read_csv("C://Users/saman/Desktop/Independent Study/Softball Project/Roster.csv")

players = []
for player in roster["Player"]:
    if player not in players:
        players.append(player)

# print(players)
# print(dates)
stats_dict = dict(Name= " ", PitchesSeen= 0, BallsHit= 0 , ExitVelo= [])
dates_dict = dict()
# print(dates_dict)
print(players[3])
# print(stats_dict)
a = 1
for a in range(len(players)):
    pitches_seen = 0
    velos = []
    for index, x in df.iterrows():
        if x["Batter"] == players[a]:
            if players[a] in stats_dict:
                stats_dict["Name"] = players[a]
                stats_dict["PitchesSeen"] = stats_dict["PitchesSeen"] + 1
                if x["Hit Ball Speed [mph]"] == " ":
                    continue
                else:
                    ev = x["Hit Ball Speed [mph]"]
                    stats_dict["ExitVelo"].append(ev)
                    day = x["Date"]
                    if day in dates_dict:
                        dates_dict[day].append(ev)
                    else:
                        dates_dict[day] = [ev]
                        stats_dict["BallsHit"] = stats_dict["BallsHit"] + 1
            else: 
                name = players[a]
                pitches_seen += 1
                if x["Hit Ball Speed [mph]"] == " ":
                    continue
                else:
                    ev = x["Hit Ball Speed [mph]"]
                    velos.append(ev)
                    day = x["Date"]
                    if day in dates_dict:
                        dates_dict[day].append(ev)
                    else:
                        dates_dict[day] = [ev]
                        stats_dict["BallsHit"] = stats_dict["BallsHit"] + 1
        else: 
            continue
    average = sum(stats_dict["ExitVelo"])/len(stats_dict["ExitVelo"])
    lists = sorted(dates_dict.items()) 

    x, y = zip(*lists)

    for xe, ye in zip(x, y):
        plt.scatter([xe] * len(ye), ye)
    plt.axhline(average)
    plt.title(players[a])
    plt.xticks(rotation=90)
    print(a)
    print(stats_dict)
    plt.show()
    a += 1

# average = sum(stats_dict["ExitVelo"])/len(stats_dict["ExitVelo"])
# # print(average)
# # print(dates_dict)
# # print(stats_dict)
# lists = sorted(dates_dict.items()) 

# x, y = zip(*lists)

# for xe, ye in zip(x, y):
#     plt.scatter([xe] * len(ye), ye)
# plt.axhline(average)
# plt.title("Season Exit Velos")
# plt.xticks(rotation=90)
# plt.show()

